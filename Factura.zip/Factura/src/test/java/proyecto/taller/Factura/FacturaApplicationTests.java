package proyecto.taller.Factura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
