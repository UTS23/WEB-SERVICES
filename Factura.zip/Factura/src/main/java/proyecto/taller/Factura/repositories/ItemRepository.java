package proyecto.taller.Factura.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import proyecto.taller.Factura.repositories.entitiy.Item;

@Repository
public interface ItemRepository extends CrudRepository<Item, Long> {
}
