package proyecto.taller.Factura.repositories.entitiy;
//BRAYAN MORENO WEB SERVICES
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "items")
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int amount;
    private int totalLine;
    
    @ManyToOne
    @JoinColumn(name = "product_id")
    @JsonIgnoreProperties("product") 
    private Product product;

    @ManyToOne
    @JoinColumn(name = "invoice_id")
    @JsonIgnoreProperties("items")
    private Invoice invoice;
}