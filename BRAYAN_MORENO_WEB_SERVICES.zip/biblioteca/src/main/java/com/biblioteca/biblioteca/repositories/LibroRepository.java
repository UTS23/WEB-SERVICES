package com.biblioteca.biblioteca.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biblioteca.biblioteca.entities.Libro;

// Repositorio de Libro
public interface LibroRepository extends JpaRepository<Libro, Long> {
    
}
