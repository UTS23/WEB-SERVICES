package com.biblioteca.biblioteca.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.biblioteca.biblioteca.entities.Autor;
import com.biblioteca.biblioteca.entities.Libro;
import com.biblioteca.biblioteca.repositories.LibroRepository;

@RestController
@RequestMapping("/libros")
public class LibroController {
    @Autowired
    private LibroRepository libroRepository;

    @GetMapping
    public List<Libro> obtenerLibrosConAutores() {
        return libroRepository.findAll();
    }

    @PostMapping("/{idLibro}")
    public Libro crearAutorParaLibro(@PathVariable Long idLibro, @RequestBody Autor autor) {
        Libro libro = libroRepository.findById(idLibro).orElseThrow();
        autor.setLibro(libro);
        libro.setAutor(autor);
        libroRepository.save(libro);
        return libro;
    }
}
