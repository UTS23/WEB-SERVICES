package com.biblioteca.biblioteca.services;
//Brayan MORENO
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biblioteca.biblioteca.entities.Libro;
import com.biblioteca.biblioteca.repositories.LibroRepository;

@Service
public class LibroService {

    @Autowired
    private LibroRepository libroRepository;

    // Método para obtener todos los libros
    public List<Libro> getAllLibros() {
        return libroRepository.findAll();
    }

    // Método para obtener un libro por ID
    public Optional<Libro> getLibroById(Long id) {
        return libroRepository.findById(id);
    }

    // Método para guardar un nuevo libro
    public Libro saveLibro(Libro libro) {
        return libroRepository.save(libro);
    }

    // Método para actualizar un libro existente
    public Libro updateLibro(Long id, Libro nuevoLibro) {
        if (libroRepository.existsById(id)) {
            nuevoLibro.setId(id);
            return libroRepository.save(nuevoLibro);
        } else {
            // Manejar el caso en el que el libro no existe
            return null;
        }
    }

    // Método para eliminar un libro por ID
    public void deleteLibro(Long id) {
        libroRepository.deleteById(id);
    }
}
