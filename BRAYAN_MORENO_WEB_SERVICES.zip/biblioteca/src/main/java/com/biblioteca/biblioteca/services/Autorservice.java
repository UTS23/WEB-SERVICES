package com.biblioteca.biblioteca.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.biblioteca.biblioteca.entities.Autor;
import com.biblioteca.biblioteca.repositories.AutorRepository;

@Service
public class Autorservice {

    @Autowired
    private AutorRepository autorRepository;

    // Método para obtener todos los autores
    public List<Autor> getAllAutores() {
        return autorRepository.findAll();
    }

    // Método para obtener un autor por ID
    public Optional<Autor> getAutorById(Long id) {
        return autorRepository.findById(id);
    }

    // Método para guardar un nuevo autor
    public Autor saveAutor(Autor autor) {
        return autorRepository.save(autor);
    }

    // Método para actualizar un autor existente
    public Autor updateAutor(Long id, Autor nuevoAutor) {
        if (autorRepository.existsById(id)) {
            nuevoAutor.setId(id);
            return autorRepository.save(nuevoAutor);
        } else {
            // Manejar el caso en el que el autor no existe
            return null;
        }
    }

    // Método para eliminar un autor por ID
    public void deleteAutor(Long id) {
        autorRepository.deleteById(id);
    }
}
