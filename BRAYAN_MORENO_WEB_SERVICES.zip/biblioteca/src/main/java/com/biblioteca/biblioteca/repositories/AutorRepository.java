package com.biblioteca.biblioteca.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.biblioteca.biblioteca.entities.Autor;

// Repositorio de Autor
public interface AutorRepository extends JpaRepository<Autor, Long> {
    
}
